#ifndef SiRobo_H
#define SiRobo_H

#include <Arduino.h>
#include "sirobo_android.h"
#include "SiRGBLed.h"
#include "SiBuzzer.h"
#include "SiTimer.h"
//#include "SiIR.h"
//#include "SiBoardIR.h"
//#include "SiOled.h"
#endif